<PLACEHOLDER: вставь сюда свой ElytraUpgradePlugin.java>
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public class ElytraUpgradePlugin extends JavaPlugin implements Listener, TabExecutor {
    private final Map<UUID, Double> distanceMap = new HashMap<>();
    private final Map<UUID, Integer> maxDurabilityMap = new HashMap<>();

    private static final int INITIAL_DURABILITY = 64;
    private static final int MAX_DURABILITY = 432;
    private static final double BLOCKS_PER_UPGRADE = 3000.0;

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("elytra")).setExecutor(this);
        getLogger().info("ElytraUpgrade enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("ElytraUpgrade disabled!");
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!player.isGliding()) return;

        UUID uuid = player.getUniqueId();
        double distance = event.getFrom().distance(event.getTo());

        distanceMap.put(uuid, distanceMap.getOrDefault(uuid, 0.0) + distance);

        ItemStack chest = player.getInventory().getChestplate();
        if (chest == null || !chest.getType().name().equalsIgnoreCase("ELYTRA")) return;

        int currentMax = maxDurabilityMap.getOrDefault(uuid, INITIAL_DURABILITY);

        while (distanceMap.get(uuid) >= BLOCKS_PER_UPGRADE && currentMax < MAX_DURABILITY) {
            distanceMap.put(uuid, distanceMap.get(uuid) - BLOCKS_PER_UPGRADE);
            currentMax++;
            setElytraDurability(chest, currentMax, getCurrentDamage(chest));

            String bar = makeProgressBar(distanceMap.get(uuid), BLOCKS_PER_UPGRADE, 20);
            player.sendMessage("§aТвои элитры улучшены! Новая макс. прочность: " + currentMax + " " + bar);

            player.playSound(player.getLocation(), "entity.player.levelup", 1.0f, 1.0f);
            player.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, player.getLocation().add(0, 1, 0), 50, 0.5, 0.5, 0.5, 0.1);
        }

        maxDurabilityMap.put(uuid, currentMax);
    }

    private void setElytraDurability(ItemStack elytra, int maxDurability, int currentDamage) {
        if (elytra.getItemMeta() instanceof Damageable meta) {
            int newDamage = Math.max(0, Math.min(maxDurability - 1, currentDamage));
            meta.setDamage(newDamage);
            elytra.setItemMeta(meta);
        }
    }

    private int getCurrentDamage(ItemStack elytra) {
        if (elytra.getItemMeta() instanceof Damageable meta) {
            return meta.getDamage();
        }
        return 0;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Эта команда только для игроков!");
            return true;
        }

        UUID uuid = player.getUniqueId();

        if (args.length == 0) {
            player.sendMessage("§eИспользование: /elytra <reset|info>");
            return true;
        }

        if (args[0].equalsIgnoreCase("reset")) {
            maxDurabilityMap.put(uuid, INITIAL_DURABILITY);
            distanceMap.put(uuid, 0.0);
            ItemStack chest = player.getInventory().getChestplate();
            if (chest != null && chest.getType().name().equalsIgnoreCase("ELYTRA")) {
                setElytraDurability(chest, INITIAL_DURABILITY, 0);
            }
            player.sendMessage("§cЭлитры сброшены до начальной прочности!");
            return true;
        }

        if (args[0].equalsIgnoreCase("info")) {
            int currentMax = maxDurabilityMap.getOrDefault(uuid, INITIAL_DURABILITY);
            double currentProgress = distanceMap.getOrDefault(uuid, 0.0);
            String bar = makeProgressBar(currentProgress, BLOCKS_PER_UPGRADE, 20);

            player.sendMessage("§eТекущая макс. прочность элитр: §a" + currentMax);
            player.sendMessage("§eПрогресс до следующего улучшения: " +
                    (int) currentProgress + "/" + (int) BLOCKS_PER_UPGRADE + " блоков");
            player.sendMessage(bar);
            return true;
        }

        return false;
    }

    public static String makeProgressBar(double current, double max, int length) {
        double percent = current / max;
        int filled = (int) Math.round(percent * length);

        StringBuilder bar = new StringBuilder("§a[");
        for (int i = 0; i < length; i++) {
            if (i < filled) {
                bar.append("■");
            } else {
                bar.append("§7■");
            }
        }
        bar.append("§a]");
        return bar.toString();
    }
}
